This github repository is set to ignore any Visual Studio type files, which includes ".lib".
But it will keep 7z files, so unzip this to get the ".lib", etc.